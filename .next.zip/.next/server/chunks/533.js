exports.id = 533;
exports.ids = [533];
exports.modules = {

/***/ 2342:
/***/ ((module) => {

// Exports
module.exports = {
	"body": "Login_body__mBYgj",
	"wraper": "Login_wraper__VpWt2",
	"logoWraper": "Login_logoWraper__LCkuz",
	"logo": "Login_logo__nnAnJ",
	"headerWraper": "Login_headerWraper__qnj_1",
	"header": "Login_header__uVn15",
	"headerh1": "Login_headerh1__2TFDO",
	"admin": "Login_admin__1yCUc",
	"formWraper": "Login_formWraper___QI5V",
	"formControl": "Login_formControl__h3zOt"
};


/***/ }),

/***/ 2769:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ LoginBlock)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(358);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__);



function LoginBlock(props) {
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Row, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Col, {
                md: 6,
                children: props.children
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Col, {
                md: 6
            })
        ]
    }));
};


/***/ }),

/***/ 7337:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Logo)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles_Login_module_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2342);
/* harmony import */ var _styles_Login_module_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_styles_Login_module_css__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _public_image_paythroughlogo_png__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7221);



function Logo() {
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: (_styles_Login_module_css__WEBPACK_IMPORTED_MODULE_2___default().logoWraper),
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
            className: (_styles_Login_module_css__WEBPACK_IMPORTED_MODULE_2___default().logo),
            src: _public_image_paythroughlogo_png__WEBPACK_IMPORTED_MODULE_1__/* ["default"].src */ .Z.src,
            alt: "logo"
        })
    }));
};


/***/ }),

/***/ 1960:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ HeaderWrapper)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

function HeaderWrapper(props) {
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: props.headerWraper,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: props.header,
            children: props.children
        })
    }));
};


/***/ }),

/***/ 6812:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Wrapper)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


function Wrapper(props) {
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: props.wrapper,
        children: props.children
    }));
};


/***/ }),

/***/ 8533:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ pages)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react-bootstrap"
var external_react_bootstrap_ = __webpack_require__(358);
// EXTERNAL MODULE: ./styles/Login.module.css
var Login_module = __webpack_require__(2342);
var Login_module_default = /*#__PURE__*/__webpack_require__.n(Login_module);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: ./components/Common/Logo/Logo.jsx
var Logo = __webpack_require__(7337);
// EXTERNAL MODULE: ./components/Common/Wrapper/Content/Wrapper.jsx
var Wrapper = __webpack_require__(6812);
// EXTERNAL MODULE: ./components/Common/Wrapper/Content/HeaderWrapper.jsx
var HeaderWrapper = __webpack_require__(1960);
// EXTERNAL MODULE: ./components/Blocks/Login/LoginBlock.jsx
var LoginBlock = __webpack_require__(2769);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: external "react-google-recaptcha"
var external_react_google_recaptcha_ = __webpack_require__(5623);
var external_react_google_recaptcha_default = /*#__PURE__*/__webpack_require__.n(external_react_google_recaptcha_);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
// EXTERNAL MODULE: ./redux/Login/LoginTypes.js
var LoginTypes = __webpack_require__(9930);
;// CONCATENATED MODULE: ./redux/Login/LoginAction.js

const doLogin = (user)=>{
    return {
        type: LoginTypes/* Login */.m,
        authToken: user.authToken,
        payload: user.responseData
    };
};
const doLogout = ()=>{
    return {
        type: LoginTypes/* Logout */.R
    };
};


// EXTERNAL MODULE: ./components/Lib/Validator/FormValidator.js
var FormValidator = __webpack_require__(1593);
// EXTERNAL MODULE: ./components/config/Config.js
var Config = __webpack_require__(6499);
;// CONCATENATED MODULE: ./components/Forms/LoginForm.jsx










const LoginForm = ()=>{
    const mounted = (0,external_react_.useRef)(true);
    const dispatch = (0,external_react_redux_.useDispatch)();
    const router = (0,router_.useRouter)();
    const { 0: responseData , 1: setResponseData  } = (0,external_react_.useState)('');
    const { 0: error , 1: setError  } = (0,external_react_.useState)("");
    const { 0: isLoading , 1: setLoading  } = (0,external_react_.useState)(false);
    const { 0: captchaToken , 1: setCapthaToken  } = (0,external_react_.useState)('');
    //USING CUSTOM HOOKS FOR USER EMAIL DATA VALIDATION 
    const { value: enteredName , isValid: enteredNameIsValid , hasError: nameInputHasError , valueChangeHandler: nameChangeHandler , inputBlurHandler: nameBlurHandler , msg: errorMessage1  } = (0,FormValidator/* EmailValidator */.on)((value)=>value.trim() !== ''
    );
    //USING CUSTOM HOOKS FOR USER PASSWORD VALIDATION
    const { value: enteredPassword , isValid: enteredPasswordIsValid , hasError: passwordInputHasError , valueChangeHandler: passwordChangeHandler , inputBlurHandler: passwordBlurHandler , reset: resetPasswordInput , resetPwd: resetPwd , msg: errorPasswordMessage  } = (0,FormValidator/* PasswordValidator */._H)((value)=>value.trim() !== ''
    );
    //GET CAPTHA TOKEN
    const handleToken = (token)=>{
        setCapthaToken(token);
    };
    (0,external_react_.useEffect)(()=>{
        if (Object.keys(responseData).length > 0 && responseData.constructor === Object) {
            if (mounted) {
                const responseCode = responseData.responseCode;
                if (responseCode === 200) {
                    dispatch(doLogin(responseData));
                    setError('');
                    const successMessage = responseData.responseMessage;
                    localStorage.setItem("isAuthanticate", 1);
                    localStorage.setItem("doRedirect", 1);
                    localStorage.setItem('authToken', responseData.authToken);
                    localStorage.setItem('authData', JSON.stringify(responseData.responseData));
                    router.push(Config/* baseUrl */.FH + "/mfa");
                } else {
                    resetPwd();
                    const errorMessage = responseData.responseMessage;
                    setTimeout(()=>setError(errorMessage)
                    );
                }
            }
        } else {
            const isAuthanticate = localStorage.getItem("isAuthanticate");
            if (isAuthanticate === "1") {
                localStorage.clear();
                dispatch(doLogout());
            }
            setLoading(false);
        }
        return ()=>{
            mounted.current = false;
            setTimeout(()=>{
                setError('');
                setLoading(false);
                setResponseData('');
            }, 5 * 1000);
        };
    }, [
        responseData
    ]);
    //FORM SUBMIT HANDELER
    const verifyLogin = (0,external_react_.useCallback)(async (e)=>{
        e.preventDefault();
        if (!enteredNameIsValid) {
            setError(" Enter a Valid Email Address");
            return;
        }
        if (!enteredPasswordIsValid) {
            setError(" Enter a Valid Password");
            return;
        }
        setLoading(true);
        resetPasswordInput();
        const callLogin = await fetch(Config/* applicationUrl */.he + "/loginApi", {
            method: 'POST',
            body: JSON.stringify({
                userName: enteredName,
                password: enteredPassword,
                captchaToken: captchaToken
            })
        });
        const loginData = await callLogin.json();
        setResponseData(loginData);
    });
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (Login_module_default()).formWraper,
        children: [
            error && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "alert alert-danger d-flex align-items-center",
                role: "alert",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                        className: "bi flex-shrink-0 me-2",
                        width: "24",
                        height: "24",
                        role: "img",
                        "aria-label": "Danger:"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        children: error
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
                onSubmit: verifyLogin,
                method: "POST",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_bootstrap_.Form.Group, {
                        className: "mb-3",
                        controlId: "formEmail",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Form.Label, {
                                children: "Email ID"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                            /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Form.Control, {
                                type: "email",
                                placeholder: "name@example.com",
                                className: (Login_module_default()).formControl,
                                onChange: nameChangeHandler,
                                onBlur: nameBlurHandler,
                                value: enteredName
                            }),
                            nameInputHasError && errorMessage1('Enter A Valid Email Address')
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_bootstrap_.Form.Group, {
                        className: "mb-4",
                        controlId: "loginPassword",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Form.Label, {
                                children: "Password"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                            /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Form.Control, {
                                type: "password",
                                "aria-describedby": "passwordHelpBlock",
                                placeholder: "\xb7\xb7\xb7\xb7\xb7\xb7\xb7\xb7",
                                className: (Login_module_default()).formControl,
                                onChange: passwordChangeHandler,
                                onBlur: passwordBlurHandler,
                                value: enteredPassword
                            }),
                            passwordInputHasError && errorPasswordMessage('Password Should Not Empty')
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (Login_module_default()).formControl,
                        children: /*#__PURE__*/ jsx_runtime_.jsx((external_react_google_recaptcha_default()), {
                            className: "g-recaptcha",
                            sitekey: Config/* recaptchaKey */.iq,
                            render: "explicit",
                            onChange: handleToken
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "d-grid",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Button, {
                            type: "submit",
                            variant: "primary",
                            size: "lg",
                            disabled: isLoading,
                            children: isLoading ? 'Verifying...' : 'Login'
                        })
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const Forms_LoginForm = (LoginForm);

;// CONCATENATED MODULE: ./pages/index.js









const Login = ()=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_bootstrap_.Container, {
        fluid: true,
        className: (Login_module_default()).body,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "description",
                        content: "Kyc On Boarding "
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "keywords",
                        content: "HTML, CSS, JavaScript"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "author",
                        content: "Paythrough Software & Solution Pvt.Ltd"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("title", {
                        children: "Csp On Boarding"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("link", {
                        href: "https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i",
                        rel: "stylesheet"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("link", {
                        rel: "stylesheet",
                        href: "https://fonts.googleapis.com/icon?family=Material+Icons"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Wrapper/* default */.Z, {
                wrapper: (Login_module_default()).wraper,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(Logo/* default */.Z, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(HeaderWrapper/* default */.Z, {
                        headerWraper: (Login_module_default()).headerWraper,
                        header: (Login_module_default()).header,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h1", {
                            className: (Login_module_default()).headerh1,
                            children: [
                                "CSP ONBOARDING",
                                /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: (Login_module_default()).admin,
                                    children: "ADMIN"
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(LoginBlock/* default */.Z, {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(Forms_LoginForm, {})
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const pages = (Login);


/***/ }),

/***/ 9930:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "m": () => (/* binding */ Login),
/* harmony export */   "R": () => (/* binding */ Logout)
/* harmony export */ });
const Login = 'Login';
const Logout = 'Logout';



/***/ })

};
;