"use strict";
exports.id = 426;
exports.ids = [426];
exports.modules = {

/***/ 7221:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/paythroughlogo.4167122c.png","height":675,"width":4341,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAABCAYAAADjAO9DAAAAK0lEQVR4nGNk2PTVy+LMxg/Ce2sF/ogY/WJ5dfj/G7eJr04aeCxh/Pf3GgAb8xJFo7VWCQAAAABJRU5ErkJggg=="});

/***/ }),

/***/ 6499:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "he": () => (/* binding */ applicationUrl),
/* harmony export */   "FH": () => (/* binding */ baseUrl),
/* harmony export */   "iq": () => (/* binding */ recaptchaKey)
/* harmony export */ });
/* unused harmony export apiUrl */
// let urlFinder, hostingUrl, splitUrl, urlHttp = '';
//URL CONFIG DYNAMIC
// if(typeof window !=="undefined"){
//     urlFinder = window.location.href;
//     splitUrl = urlFinder.split("/");
//     urlHttp = splitUrl[0];
//     hostingUrl = splitUrl[2];
// }
//SET ALL URL
// const applicationUrl = urlHttp+"//"+hostingUrl+"/api";
// const baseUrl = urlHttp+"//"+hostingUrl;
// const apiUrl = "https://onboarding.paythrough.in/dev/v1/adminapi";
// const recaptchaKey = "6LeCz6UeAAAAAFNB9N_yfwivy772K0D3uIAFFOck";
const applicationUrl = "https://kycadmin.sudipchatterjee.com/api";
const baseUrl = "https://kycadmin.sudipchatterjee.com/";
const apiUrl = "https://onboarding.paythrough.in/dev/v1/adminapi";
//GOOGLE CAPTCHA KEY
const recaptchaKey = "6LeCz6UeAAAAAFNB9N_yfwivy772K0D3uIAFFOck";



/***/ })

};
;