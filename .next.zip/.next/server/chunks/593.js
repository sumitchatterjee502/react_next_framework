"use strict";
exports.id = 593;
exports.ids = [593];
exports.modules = {

/***/ 1593:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "jL": () => (/* binding */ InputCharacter),
/* harmony export */   "on": () => (/* binding */ EmailValidator),
/* harmony export */   "Rn": () => (/* binding */ InputNumber),
/* harmony export */   "_H": () => (/* binding */ PasswordValidator),
/* harmony export */   "YS": () => (/* binding */ PhNumber)
/* harmony export */ });
/* unused harmony export InputValidator */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


//INPUT VALIDATION FUNCTION
const InputValidator = (validValue)=>{
    const { 0: enteredValue , 1: setEnteredValue  } = useState('');
    const { 0: isTouched , 1: setIsTouched  } = useState(false);
    const valueIsValid = validValue(enteredValue); //CHECK TRUE OR FALSE
    const hasError = !valueIsValid && isTouched;
    //state change input wise
    const valueChangeHandler = useCallback((e)=>{
        const inputData = removeStripTags(e.target.value);
        if (inputData) {
            setEnteredValue(inputData);
        } else {
            setEnteredValue('');
        }
    });
    //check is input element is toched or not
    const inputBlurHandler = useCallback((e)=>{
        setIsTouched(true);
    });
    //remove strips tags
    const removeStripTags = useCallback((str)=>{
        if (str === null || str === '' || str === ' ') {
            return false;
        } else {
            const strd = str.toString();
            return strd.replace(/[&\/\\#,`=^+()$~%.'":*?<>{}]/g, '');
        }
    });
    //dynamic Classes Added is valid or not vaild
    const inputClasses = useCallback((failureClasses, successClasses)=>{
        return hasError ? failureClasses : successClasses;
    });
    //error message print
    const errorMessage = useCallback((message)=>{
        return(/*#__PURE__*/ _jsx("p", {
            className: "text-danger",
            children: message
        }));
    });
    //form reset element
    const reset = useCallback(()=>{
        setEnteredValue('');
        setIsTouched(false);
    });
    return {
        value: enteredValue,
        valueChangeHandler,
        inputBlurHandler,
        isValid: valueIsValid,
        hasError,
        classes: inputClasses,
        msg: errorMessage,
        reset
    };
};
//INPUT CHARACTER VALIDATION FUNCTION
const InputCharacter = (validValue)=>{
    const { 0: enteredValue , 1: setEnteredValue  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)('');
    const { 0: isTouched , 1: setIsTouched  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const valueIsValid = validValue(enteredValue); //CHECK TRUE OR FALSE
    const hasError = !valueIsValid && isTouched;
    //state change input wise
    const valueChangeHandler = (e)=>{
        const inputData = removeStripTags(e.target.value);
        if (inputData) {
            setEnteredValue(inputData.toUpperCase());
        } else {
            setEnteredValue('');
        }
    };
    //check is input element is toched or not
    const inputBlurHandler = (e)=>{
        setIsTouched(true);
    };
    //remove strips tags
    const removeStripTags = (str)=>{
        if (str === null || str === '' || str === ' ') {
            return false;
        } else {
            const strd = str.toString();
            return strd.replace(/[&\/\\#,`=^+()$~%.@'":*?<>!_{}0-9]/g, '');
        }
    };
    //dynamic Classes Added is valid or not vaild
    const inputClasses = (failureClasses, successClasses)=>{
        return hasError ? failureClasses : successClasses;
    };
    //error message print
    const errorMessage = (message)=>{
        return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
            className: "text-danger",
            children: message
        }));
    };
    //form reset element
    const reset = ()=>{
        setEnteredValue('');
        setIsTouched(false);
    };
    return {
        value: enteredValue,
        valueChangeHandler,
        inputBlurHandler,
        isValid: valueIsValid,
        hasError,
        classes: inputClasses,
        msg: errorMessage,
        reset
    };
};
//EMAIL VALIDATION FUNCTION
const EmailValidator = (validValue)=>{
    const { 0: enteredValue , 1: setEnteredValue  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)('');
    const { 0: isTouched , 1: setIsTouched  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const regex = /^(([^<>!()[\]\.,!;:\s@\"]+(\.[^<>()![\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()![\]\.,;!:\s@\"]+\.)+[^<>()![\]\.,!;:\s@\"]{2,})$/i;
    const valueIsValid = regex.test(enteredValue);
    const hasError = !valueIsValid && isTouched;
    const valueChangeHandler = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((e)=>{
        const inputData = removeStripTags(e.target.value);
        if (inputData) {
            setEnteredValue(inputData);
        } else {
            setEnteredValue('');
        }
    });
    const inputBlurHandler = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((e)=>{
        setIsTouched(true);
    });
    //remove strips tags
    const removeStripTags = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((str)=>{
        if (str === null || str === '' || str === ' ') {
            return false;
        } else {
            const strd = str.toString();
            return strd.replace(/^[&\/\\[\];#,`=^+()|!$~%'":*?<>{}]/g, '');
        }
    });
    //dynamic Classes Added is valid or not vaild
    const inputClasses = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((failureClasses, successClasses)=>{
        return hasError ? failureClasses : successClasses;
    });
    //error message print
    const errorMessage = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((message)=>{
        return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
            className: "text-danger",
            children: message
        }));
    });
    //form reset element
    const reset = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(()=>{
        setEnteredValue('');
        setIsTouched(false);
    });
    return {
        value: enteredValue,
        valueChangeHandler,
        inputBlurHandler,
        isValid: valueIsValid,
        hasError,
        classes: inputClasses,
        msg: errorMessage,
        reset
    };
};
//INPUT NUMBER VALIDATION FUNCTION
const InputNumber = (vaildValue)=>{
    const { 0: enteredValue , 1: setEnteredValue  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)('');
    const { 0: isTouched , 1: setIsTouched  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const validate = (data)=>{
        const regex = /^(\d{0,6})$/i;
        const a = regex.test(data);
        return a;
    };
    const valueIsValid = validate(enteredValue);
    const hasError = !valueIsValid && isTouched;
    const valueChangeHandler = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((e)=>{
        const re = /^[0-9\b]+$/;
        if (e.target.value === '' || re.test(e.target.value)) {
            setEnteredValue(e.target.value);
        }
    });
    const inputBlurHandler = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((e)=>{
        setIsTouched(true);
    });
    //remove strips tags
    const removeStripTags = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((str)=>{
        const re = /^[0-9\b]+$/;
        if (str === null || str === '' || str === ' ' || re.test(str)) {
            return str;
        }
    });
    //dynamic Classes Added is valid or not vaild
    const inputClasses = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((failureClasses, successClasses)=>{
        return hasError ? failureClasses : successClasses;
    });
    //error message print
    const errorMessage = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((message)=>{
        return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
            className: "text-danger",
            children: message
        }));
    });
    //form reset element
    const reset = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(()=>{
        setEnteredValue('');
        setIsTouched(false);
    });
    return {
        value: enteredValue,
        valueChangeHandler,
        inputBlurHandler,
        isValid: valueIsValid,
        hasError,
        classes: inputClasses,
        msg: errorMessage,
        reset
    };
};
const PhNumber = (vaildValue)=>{
    const { 0: enteredValue , 1: setEnteredValue  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)('');
    const { 0: isTouched , 1: setIsTouched  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const validate = (data)=>{
        const regex = /^(\d{10})$/i;
        const a = regex.test(data);
        return a;
    };
    const valueIsValid = validate(enteredValue);
    const hasError = !valueIsValid && isTouched;
    const valueChangeHandler = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((e)=>{
        const re = /^[0-9\b]+$/;
        if (e.target.value === '' || re.test(e.target.value)) {
            setEnteredValue(e.target.value);
        }
    });
    // const valueChangeHandler = useCallback(e =>{
    //     const inputData = removeStripTags(e.target.value);
    //     if(inputData){
    //         setEnteredValue(inputData);
    //     }else{
    //         setEnteredValue('');
    //     }   
    // })
    const inputBlurHandler = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((e)=>{
        setIsTouched(true);
    });
    //remove strips tags
    const removeStripTags = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((str)=>{
        if (str === null || str === '' || str === ' ') {
            return false;
        } else {
            const strd = str.toString();
            return strd.replace(/[&\/\\#,`=^+()$~%'.":;^[]*?<>{}]/g, '');
        }
    });
    //dynamic Classes Added is valid or not vaild
    const inputClasses = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((failureClasses, successClasses)=>{
        return hasError ? failureClasses : successClasses;
    });
    //error message print
    const errorMessage = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((message)=>{
        return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
            className: "text-danger",
            children: message
        }));
    });
    //form reset element
    const reset = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(()=>{
        setEnteredValue('');
        setIsTouched(false);
    });
    return {
        value: enteredValue,
        valueChangeHandler,
        inputBlurHandler,
        isValid: valueIsValid,
        hasError,
        classes: inputClasses,
        msg: errorMessage,
        reset
    };
};
//Password Validator
const PasswordValidator = (validateValue)=>{
    const { 0: enteredValue , 1: setEnteredValue  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)('');
    const { 0: isTouched , 1: setIsTouched  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const valueIsValid = validateValue(enteredValue);
    const validate = (data)=>{
        const paswd = /^(?=.*[0-9])(?=.*[A-Z])(?=.*[a-z])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{6,20}$/;
        const a = paswd.test(data);
        return a;
    };
    const checkPassword = validate(enteredValue);
    const hasError = !checkPassword && isTouched;
    const valueChangeHandler = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((e)=>{
        setEnteredValue(e.target.value);
    });
    const inputBlurHandler = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((e)=>{
        setIsTouched(true);
    });
    const createUniqueKey = (e)=>{
        for(var a = [], r = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789", c = r.length, s = 0; s < e; s++)a.push(r.charAt(Math.floor(Math.random() * c)));
        return a.join("");
    };
    const reset = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(()=>{
        const Pwd = createUniqueKey(32);
        setEnteredValue(Pwd);
        setIsTouched(false);
    });
    const resetPwd = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(()=>{
        setEnteredValue('');
        setIsTouched(false);
    });
    const nameInputClasses = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(()=>{
        return hasError ? 'form-control is-invalid' : 'form-control';
    });
    const errorMessage = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((message)=>{
        if (!valueIsValid && isTouched) {
            return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                className: "text-danger",
                children: message
            }));
        } else if (hasError) {
            return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                className: "text-danger",
                children: "Password Contain (Upper & LowerCase Number Symbol) & 6 digit"
            }));
        }
    });
    return {
        value: enteredValue,
        isValid: valueIsValid,
        hasError,
        classes: nameInputClasses,
        valueChangeHandler,
        inputBlurHandler,
        reset,
        resetPwd,
        msg: errorMessage
    };
};



/***/ })

};
;