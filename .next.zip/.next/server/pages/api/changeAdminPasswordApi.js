"use strict";
(() => {
var exports = {};
exports.id = 235;
exports.ids = [235];
exports.modules = {

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 3160:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "JW": () => (/* binding */ apiUrl)
/* harmony export */ });
/* unused harmony exports applicationUrl, baseUrl, recaptchaKey */
// let urlFinder, hostingUrl, splitUrl, urlHttp = '';
//URL CONFIG DYNAMIC
// if(typeof window !=="undefined"){
//     urlFinder = window.location.href;
//     splitUrl = urlFinder.split("/");
//     urlHttp = splitUrl[0];
//     hostingUrl = splitUrl[2];
// }
//SET ALL URL
// const applicationUrl = urlHttp+"//"+hostingUrl+"/api";
// const baseUrl = urlHttp+"//"+hostingUrl;
// const apiUrl = "https://onboarding.paythrough.in/dev/v1/adminapi";
// const recaptchaKey = "6LeCz6UeAAAAAFNB9N_yfwivy772K0D3uIAFFOck";
const applicationUrl = "https://kycadmin.sudipchatterjee.com/api";
const baseUrl = "https://kycadmin.sudipchatterjee.com/";
const apiUrl = "https://onboarding.paythrough.in/dev/v1/adminapi";
//GOOGLE CAPTCHA KEY
const recaptchaKey = "6LeCz6UeAAAAAFNB9N_yfwivy772K0D3uIAFFOck";



/***/ }),

/***/ 3573:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_config_Config__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3160);


const ChangeAdminPasswordApi = (req, res)=>{
    if (req.method === "POST") {
        const data = JSON.parse(req.body);
        const headers = {
            'Content-Type': 'application/json',
            'Authorization': data.authToken ? 'Bearer ' + data.authToken : ''
        };
        axios__WEBPACK_IMPORTED_MODULE_0___default().post(_components_config_Config__WEBPACK_IMPORTED_MODULE_1__/* .apiUrl */ .JW + '/ownChangePasswordAdminUser', {
            oldPassword: oldPassword,
            newPassword: newPassword
        }, {
            headers: headers
        }).then((resp)=>{
            const responseCode = resp.data.responseCode;
            if (responseCode === 200) {
                const successMessage = resp.data.responseMessage;
                return res.json({
                    responseCode: responseCode,
                    responseMessage: successMessage
                });
            } else if (responseCode === 401) {
                const errorMessage = resp.data.responseMessage;
                return res.json({
                    responseCode: responseCode,
                    responseMessage: errorMessage
                });
            } else {
                const errorMessage = resp.data.responseMessage;
                return res.json({
                    responseCode: responseCode,
                    responseMessage: errorMessage
                });
            }
        }).catch((err)=>{
            return res.json({
                responseCode: "502",
                responseMessage: "BAD REQUEST: API ERROR"
            });
        });
    } else {
        return res.json({
            responseCode: "403",
            responseMessage: "BAD REQUEST: GET METHOD NOT ALLOWED"
        });
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ChangeAdminPasswordApi);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(3573));
module.exports = __webpack_exports__;

})();